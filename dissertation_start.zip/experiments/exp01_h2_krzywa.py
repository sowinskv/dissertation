"""
Eksperyment 01: krzywa energii potencjalnej H2.

Porównuje cztery metody dla cząsteczki H2 w bazie STO-3G:
  - HF   (Hartree-Fock, klasycznie, PySCF)        -> punkt startowy, bez korelacji
  - FCI  (pełna interakcja konfiguracji, PySCF)   -> wynik dokładny w tej bazie
  - VQE-UCCSD (QNN z ansatzem chemicznym)
  - VQE-HEA   (QNN z ansatzem sprzętowo-wydajnym)

Wynik: tabela w konsoli, plik CSV i wykres PNG (rysunek 6.1 w pracy).

Instalacja:  pip install qiskit qiskit-nature pyscf matplotlib
Uruchomienie (z katalogu głównego repo): python experiments/exp01_h2_krzywa.py
Sprawdzone z: qiskit 2.5.2, qiskit-nature 0.8.0, pyscf 2.14.0, Python 3.12
"""

import csv
import time
import warnings

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

from pyscf import gto, scf, fci
from qiskit import transpile
from qiskit.circuit.library import efficient_su2
from qiskit.primitives import StatevectorEstimator
from qiskit_nature.second_q.drivers import PySCFDriver
from qiskit_nature.second_q.mappers import ParityMapper
from qiskit_nature.second_q.circuit.library import HartreeFock, UCCSD

warnings.filterwarnings("ignore")  # ostrzeżenia scipy o macierzach rzadkich nie mają znaczenia

# ---------------- konfiguracja eksperymentu ----------------
R_VALUES = np.linspace(0.3, 3.0, 19)   # długości wiązania w angstremach
HEA_REPS = 2                           # liczba warstw ansatzu sprzętowo-wydajnego
SEED = 42                              # ziarno losowości (powtarzalność)
CHEM_ACC = 1.6e-3                      # dokładność chemiczna w Ha
BASIS_GATES = ["cx", "rz", "sx", "x"]  # bramki natywne typowego procesora IBM

estimator = StatevectorEstimator()     # symulator bez szumu: dokładne wartości oczekiwane
rng = np.random.default_rng(SEED)


# ---------------- krok 1: klasyczna chemia (PySCF) ----------------
def classical_reference(R):
    """Zwraca energie HF i FCI policzone bezpośrednio w PySCF (niezależna kontrola)."""
    mol = gto.M(atom=f"H 0 0 0; H 0 0 {R}", basis="sto3g", verbose=0)
    mf = scf.RHF(mol).run()
    e_fci, _ = fci.FCI(mf).kernel()
    return mf.e_tot, e_fci


# ---------------- krok 2: hamiltonian kubitowy ----------------
def qubit_problem(R):
    """Hamiltonian H2 jako suma członów Pauliego na kubitach.

    PySCFDriver liczy całki molekularne, second_q_op() zapisuje hamiltonian
    w drugiej kwantyzacji, a ParityMapper zamienia go na kubity i usuwa
    2 kubity dzięki symetriom (4 spin-orbitale -> 2 kubity).
    """
    problem = PySCFDriver(atom=f"H 0 0 0; H 0 0 {R}", basis="sto3g").run()
    mapper = ParityMapper(num_particles=problem.num_particles)
    qubit_op = mapper.map(problem.hamiltonian.second_q_op())
    e_nuc = problem.hamiltonian.nuclear_repulsion_energy  # stałe odpychanie jąder
    return problem, mapper, qubit_op, e_nuc


# ---------------- krok 3: dwie architektury QNN ----------------
def build_ansatze(problem, mapper):
    hf = HartreeFock(problem.num_spatial_orbitals, problem.num_particles, mapper)
    uccsd = UCCSD(problem.num_spatial_orbitals, problem.num_particles, mapper,
                  initial_state=hf)
    # HEA: warstwy obrotów RY, RZ + CNOT między sąsiednimi kubitami, start ze stanu HF
    hea = hf.compose(efficient_su2(hf.num_qubits, reps=HEA_REPS, entanglement="linear"))
    return uccsd, hea


def circuit_resources(circuit):
    """Zasoby obwodu po rozłożeniu na bramki natywne sprzętu."""
    t = transpile(circuit, basis_gates=BASIS_GATES, optimization_level=1)
    return {"params": circuit.num_parameters,
            "cnot": t.count_ops().get("cx", 0),
            "depth": t.depth()}


# ---------------- krok 4: VQE = trening QNN ----------------
def run_vqe(ansatz, qubit_op, e_nuc, theta0):
    """Minimalizuje E(theta) = <psi(theta)|H|psi(theta)> klasycznym optymalizatorem."""
    def energy(theta):
        result = estimator.run([(ansatz, qubit_op, theta)]).result()[0]
        return float(result.data.evs) + e_nuc

    res = minimize(energy, theta0, method="L-BFGS-B", options={"maxiter": 500})
    return res.fun, res.nfev


# ---------------- główna pętla ----------------
def main():
    rows = []
    start = time.time()
    print(f"{'R [Å]':>6} {'HF':>11} {'FCI':>11} {'UCCSD':>11} {'HEA':>11}"
          f" {'ΔE UCCSD [mHa]':>15} {'ΔE HEA [mHa]':>13}")

    for R in R_VALUES:
        e_hf, e_fci = classical_reference(R)
        problem, mapper, qubit_op, e_nuc = qubit_problem(R)

        # test poprawności mapowania: najniższa wartość własna = FCI z PySCF
        e_exact = np.linalg.eigvalsh(qubit_op.to_matrix())[0] + e_nuc
        assert abs(e_exact - e_fci) < 1e-8, f"Mapowanie niezgodne z FCI dla R={R}"

        uccsd, hea = build_ansatze(problem, mapper)
        e_ucc, nfev_ucc = run_vqe(uccsd, qubit_op, e_nuc, np.zeros(uccsd.num_parameters))
        e_hea, nfev_hea = run_vqe(hea, qubit_op, e_nuc,
                                  rng.uniform(-0.1, 0.1, hea.num_parameters))

        rows.append({"R": R, "HF": e_hf, "FCI": e_fci, "UCCSD": e_ucc, "HEA": e_hea,
                     "dE_UCCSD": abs(e_ucc - e_fci), "dE_HEA": abs(e_hea - e_fci),
                     "nfev_UCCSD": nfev_ucc, "nfev_HEA": nfev_hea})
        print(f"{R:6.2f} {e_hf:11.6f} {e_fci:11.6f} {e_ucc:11.6f} {e_hea:11.6f}"
              f" {1e3 * abs(e_ucc - e_fci):15.2e} {1e3 * abs(e_hea - e_fci):13.2e}")

    # zasoby obwodów (nie zależą od R, więc liczymy raz)
    uccsd, hea = build_ansatze(*qubit_problem(R_VALUES[0])[:2])
    res_ucc, res_hea = circuit_resources(uccsd), circuit_resources(hea)

    # podsumowanie
    print(f"\nCzas: {time.time() - start:.1f} s")
    for name, res, key in [("UCCSD", res_ucc, "UCCSD"), ("HEA", res_hea, "HEA")]:
        d = np.array([r[f"dE_{key}"] for r in rows])
        nfev = np.mean([r[f"nfev_{key}"] for r in rows])
        print(f"{name:6s} parametry={res['params']:2d}  CNOT={res['cnot']:2d}  "
              f"głębokość={res['depth']:3d}  śr. ewaluacji={nfev:6.1f}  "
              f"maks. ΔE={1e3 * d.max():.2e} mHa  "
              f"punkty z dokładnością chemiczną: {100 * np.mean(d <= CHEM_ACC):.0f}%")

    # zapis wyników
    with open("results/exp01_h2_wyniki.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    # wykres: krzywa energii + błąd względem FCI w skali logarytmicznej
    R = [r["R"] for r in rows]
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7, 8), sharex=True)
    ax1.plot(R, [r["HF"] for r in rows], "o--", color="C0", label="HF")
    ax1.plot(R, [r["FCI"] for r in rows], "k-", label="FCI (dokładne)")
    ax1.plot(R, [r["UCCSD"] for r in rows], "s", color="C1", mfc="none", label="VQE-UCCSD")
    ax1.plot(R, [r["HEA"] for r in rows], "^", color="C2", mfc="none",
             label=f"VQE-HEA (L={HEA_REPS})")
    ax1.set_ylabel("Energia [Ha]")
    ax1.set_title("H₂ / STO-3G: krzywa energii potencjalnej")
    ax1.legend()

    floor = 1e-10  # błąd równy 0 nie da się narysować w skali log
    ax2.semilogy(R, [max(abs(r["HF"] - r["FCI"]) * 1e3, floor) for r in rows], "o--",
                 color="C0", label="HF")
    ax2.semilogy(R, [max(r["dE_UCCSD"] * 1e3, floor) for r in rows], "s-",
                 color="C1", label="VQE-UCCSD")
    ax2.semilogy(R, [max(r["dE_HEA"] * 1e3, floor) for r in rows], "^-",
                 color="C2", label="VQE-HEA")
    ax2.axhline(CHEM_ACC * 1e3, color="red", ls=":", label="dokładność chemiczna (1,6 mHa)")
    ax2.set_xlabel("Długość wiązania R [Å]")
    ax2.set_ylabel("|E − E_FCI| [mHa]")
    ax2.legend(loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=2)
    fig.tight_layout()
    fig.savefig("results/exp01_h2_krzywa.png", dpi=150)
    print("Zapisano: results/exp01_h2_wyniki.csv, results/exp01_h2_krzywa.png")


if __name__ == "__main__":
    main()
